package com.aayushmc.fasteredit.utils;

import org.bukkit.command.CommandSender;

public class PermissionUtils {
    public static boolean hasEditPermission(CommandSender sender) {
            return sender.isOp() || sender.hasPermission("fasteredit.command.*");
                }
                }