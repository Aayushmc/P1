package com.aayushmc.fasteredit.utils;

import org.bukkit.Location;

public class RegionUtils {
    public static boolean isInCuboid(Location loc, Location pos1, Location pos2) {
            double minX = Math.min(pos1.getX(), pos2.getX());
                    double maxX = Math.max(pos1.getX(), pos2.getX());
                            double minY = Math.min(pos1.getY(), pos2.getY());
                                    double maxY = Math.max(pos1.getY(), pos2.getY());
                                            double minZ = Math.min(pos1.getZ(), pos2.getZ());
                                                    double maxZ = Math.max(pos1.getZ(), pos2.getZ());
                                                            return loc.getX() >= minX && loc.getX() <= maxX &&
                                                                           loc.getY() >= minY && loc.getY() <= maxY &&
                                                                                          loc.getZ() >= minZ && loc.getZ() <= maxZ;
                                                                                              }
                                                                                              }