package com.aayushmc.fasteredit.utils;

import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.command.CommandSender;

public class ChatUtils {
    public static void sendClickableMessage(CommandSender sender, String message, String allowCmd, String denyCmd) {
            TextComponent base = new TextComponent(message);
                    TextComponent allow = new TextComponent(" §a[Allow]");
                            allow.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, allowCmd));
                                    TextComponent deny = new TextComponent(" §c[Deny]");
                                            deny.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, denyCmd));
                                                    sender.spigot().sendMessage(base, allow, deny);
                                                        }
                                                        }