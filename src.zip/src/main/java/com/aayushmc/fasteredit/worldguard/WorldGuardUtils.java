package com.aayushmc.fasteredit.worldguard;

import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.BukkitAdapter;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import com.sk89q.worldguard.protection.regions.RegionManager;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class WorldGuardUtils {
    public static boolean canEdit(Player player, Location loc) {
            RegionContainer container = WorldGuard.getInstance().getPlatform().getRegionContainer();
                    RegionManager regions = container.get(BukkitAdapter.adapt(loc.getWorld()));
                            if (regions == null) return true;
                                    ApplicableRegionSet set = regions.getApplicableRegions(BukkitAdapter.asBlockVector(loc));
                                            // Checks if the player has build permission in the region
                                                    return set.testState(BukkitAdapter.adapt(player), Flags.BUILD);
                                                        }
                                                        }