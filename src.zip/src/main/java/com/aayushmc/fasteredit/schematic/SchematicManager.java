package com.aayushmc.fasteredit.schematic;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SchematicManager {
    // Unload schematic (stub, actual implementation depends on clipboard management)
    public boolean unloadSchematic(String name) {
        // TODO: Remove schematic from clipboard or memory
        return true;
    }

    // Delete schematic file
    public boolean deleteSchematic(String name) {
        File file = getSchematicFile(name);
        return file.exists() && file.delete();
    }
    private final File schematicsFolder;

    public SchematicManager(File dataFolder) {
        this.schematicsFolder = new File(dataFolder, "schematics");
        if (!schematicsFolder.exists()) {
            schematicsFolder.mkdirs();
        }
    }

    public List<String> listSchematics() {
        List<String> list = new ArrayList<>();
        File[] files = schematicsFolder.listFiles((dir, name) -> name.endsWith(".schem"));
        if (files != null) {
            for (File file : files) {
                list.add(file.getName().replace(".schem", ""));
            }
        }
        return list;
    }

    public File getSchematicFile(String name) {
        return new File(schematicsFolder, name + ".schem");
    }
}
