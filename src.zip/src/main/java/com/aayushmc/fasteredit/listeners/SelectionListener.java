package com.aayushmc.fasteredit.listeners;

import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.entity.Player;

public class SelectionListener implements Listener {
    @EventHandler
        public void onPlayerInteract(PlayerInteractEvent event) {
                Player player = event.getPlayer();
                        // TODO: Handle wand selection for pos1/pos2
                                // Example: If player right/left clicks with wand, set pos1/pos2
                                    }
                                    }