package com.aayushmc.fasteredit.listeners;

import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.entity.Player;

public class BlockEditListener implements Listener {
    @EventHandler
        public void onBlockPlace(BlockPlaceEvent event) {
                Player player = event.getPlayer();
                        // TODO: Check WorldGuard, permissions, and handle block place for edit history
                            }

                                @EventHandler
                                    public void onBlockBreak(BlockBreakEvent event) {
                                            Player player = event.getPlayer();
                                                    // TODO: Check WorldGuard, permissions, and handle block break for edit history
                                                        }
                                                        }