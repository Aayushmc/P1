package com.aayushmc.fasteredit;

import org.bukkit.plugin.java.JavaPlugin;

public class FasterEdit extends JavaPlugin {
    @Override
    public void onEnable() {
        printStartupBox();
        // TODO: Register commands and listeners
    }

    private void printStartupBox() {
        String[] lines = {
            "Made By aayushmc0",
            "Fastedit",
            "1.20 tp 1.21.8"
        };
        String border = "§b+--------------------------+";
        getServer().getConsoleSender().sendMessage(border);
        for (String line : lines) {
            String padded = String.format("§b| §f%-22s§b|", line);
            getServer().getConsoleSender().sendMessage(padded);
        }
        getServer().getConsoleSender().sendMessage(border);
    }
}
