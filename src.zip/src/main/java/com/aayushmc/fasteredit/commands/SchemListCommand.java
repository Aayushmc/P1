package com.aayushmc.fasteredit.commands;

import com.aayushmc.fasteredit.schematic.SchematicManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public class SchemListCommand implements CommandExecutor {
    private final SchematicManager schematicManager;

    public SchemListCommand(JavaPlugin plugin) {
        this.schematicManager = new SchematicManager(plugin.getDataFolder());
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        List<String> schems = schematicManager.listSchematics();
        if (schems.isEmpty()) {
            sender.sendMessage("§cNo schematics found.");
            return true;
        }
        sender.sendMessage("§eSchematics:");
            for (String name : schems) {
                sender.sendMessage("§b- " + name + " §a[+]Load §c[-]Unload §4[×]Delete");
            }
        return true;
    }
}
