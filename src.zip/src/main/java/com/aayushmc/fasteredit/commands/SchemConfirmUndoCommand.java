package com.aayushmc.fasteredit.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class SchemConfirmUndoCommand implements CommandExecutor {
    @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
                if (!sender.isOp()) {
                            sender.sendMessage("§cOnly operators can use this command.");
                                        return true;
                                                }
                                                        // TODO: Implement schematic undo logic
                                                                sender.sendMessage("§aSchematic undo confirmed.");
                                                                        return true;
                                                                            }
                                                                            }