package com.aayushmc.fasteredit.commands;

import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class SchemUndoCommand implements CommandExecutor {
    @Override
        public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
                if (!sender.isOp()) {
                            sender.sendMessage("§cOnly operators can use this command.");
                                        return true;
                                                }
                                                        TextComponent allow = new TextComponent("§a[Allow]");
                                                                allow.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/schematic confirmundo"));
                                                                        TextComponent deny = new TextComponent("§c[Deny]");
                                                                                deny.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/schematic cancelundo"));
                                                                                        sender.spigot().sendMessage(new TextComponent("§eUndo last schematic action? "), allow, new TextComponent(" "), deny);
                                                                                                return true;
                                                                                                    }
                                                                                                    }