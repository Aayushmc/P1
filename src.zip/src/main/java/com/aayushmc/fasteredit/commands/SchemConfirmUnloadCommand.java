package com.aayushmc.fasteredit.commands;

import com.aayushmc.fasteredit.schematic.SchematicManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class SchemConfirmUnloadCommand implements CommandExecutor {
    private final SchematicManager schematicManager;

        public SchemConfirmUnloadCommand(JavaPlugin plugin) {
                this.schematicManager = new SchematicManager(plugin.getDataFolder());
                    }

                        @Override
                            public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
                                    if (!sender.isOp()) {
                                                sender.sendMessage("§cOnly operators can use this command.");
                                                            return true;
                                                                    }
                                                                            if (args.length < 1) {
                                                                                        sender.sendMessage("§cUsage: /schematic confirmunload <name>");
                                                                                                    return true;
                                                                                                            }
                                                                                                                    String name = args[0];
                                                                                                                            boolean success = schematicManager.unloadSchematic(name);
                                                                                                                                    sender.sendMessage(success ? "§aSchematic '" + name + "' unloaded." : "§cFailed to unload schematic.");
                                                                                                                                            return true;
                                                                                                                                                }
                                                                                                                                                }