package com.aayushmc.fasteredit.commands;

import com.aayushmc.fasteredit.schematic.SchematicManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class SchemLoadCommand implements CommandExecutor {
    private final SchematicManager schematicManager;

    public SchemLoadCommand(JavaPlugin plugin) {
        this.schematicManager = new SchematicManager(plugin.getDataFolder());
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage("§cUsage: /schem load <name>");
            return true;
        }
        String name = args[0];
        // TODO: Load schematic file and set to player's clipboard
        sender.sendMessage("§aLoaded schematic: " + name);
        return true;
    }
}
