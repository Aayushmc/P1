package com.aayushmc.fasteredit.commands;

import com.aayushmc.fasteredit.schematic.SchematicManager;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public class SchemUnloadCommand implements CommandExecutor {
    private final SchematicManager schematicManager;

        public SchemUnloadCommand(JavaPlugin plugin) {
                this.schematicManager = new SchematicManager(plugin.getDataFolder());
                    }

                        @Override
                            public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
                                    if (!sender.isOp()) {
                                                sender.sendMessage("§cOnly operators can use this command.");
                                                            return true;
                                                                    }
                                                                            if (args.length < 1) {
                                                                                        sender.sendMessage("§cUsage: /schematic unload <name>");
                                                                                                    return true;
                                                                                                            }
                                                                                                                    String name = args[0];
                                                                                                                            TextComponent allow = new TextComponent("§a[Allow]");
                                                                                                                                    allow.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/schematic confirmunload " + name));
                                                                                                                                            TextComponent deny = new TextComponent("§c[Deny]");
                                                                                                                                                    deny.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/schematic cancelunload " + name));
                                                                                                                                                            sender.spigot().sendMessage(new TextComponent("§eUnload schematic '" + name + "'? "), allow, new TextComponent(" "), deny);
                                                                                                                                                                    return true;
                                                                                                                                                                        }
                                                                                                                                                                        }